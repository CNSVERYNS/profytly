export type VehicleAiReportInput = {
  vehicle: {
    title: string | null;
    auctionUrl: string;
    source: string | null;
    lotNumber: string | null;
    location: string | null;
    stateCode: string | null;
    titleStatus: string | null;
    mileage: number | null;
    mileageUnit: string | null;
    primaryDamage: string | null;
    secondaryDamage: string | null;
    runCondition: string | null;
  };

  analysis: {
    status: "pending" | "completed" | "limited" | "failed";
    marketValueLow: number | null;
    marketValueHigh: number | null;
    marketValueEstimate: number | null;
    asIsValueLow: number | null;
    asIsValueHigh: number | null;
    asIsValueEstimate: number | null;
    confidenceScore: number | null;
    visionUsed: boolean | null;
    imageCountAnalyzed: number | null;
    visibleDamage: string[];
    hiddenDamageRisks: string[];
    repairRisk: "low" | "medium" | "high" | "unknown" | null;
    riskScore: number | null;
    visibleRepairCostLow: number | null;
    visibleRepairCostHigh: number | null;
    visibleRepairCostEstimate: number | null;
    hiddenDamageContingencyLow: number | null;
    hiddenDamageContingencyHigh: number | null;
    hiddenDamageContingencyEstimate: number | null;
    repairCostLow: number | null;
    repairCostHigh: number | null;
    repairCostEstimate: number | null;
    profytScore: number | null;
    recommendedBid: number | null;
    recommendation:
      | "strong_buy"
      | "buy"
      | "watch"
      | "avoid"
      | "insufficient_data"
      | null;
    summary: string | null;
    keyFactors: string[];
    warnings: string[];
    comparableVehicles: Array<{
      title: string;
      price: number | null;
      mileage: number | null;
      location: string | null;
      url: string | null;
      source: string;
    }>;
    modelName: string | null;
    createdAt: string;
  };

  assumptions: {
    desiredProfit: number;
    repairs: number;
    transport: number;
    fees: number;
  };

  photoUrls: string[];
  notes: Array<{
    content: string;
    createdAt: string;
  }>;
};

export function exportVehicleAiDecisionReport(
  input: VehicleAiReportInput,
  existingWindow?: Window | null
) {
  if (typeof window === "undefined") {
    return;
  }

  const reportWindow = existingWindow ?? window.open("", "_blank");

  if (!reportWindow) {
    throw new Error(
      "Popup blocked. Please allow popups to export the AI report PDF."
    );
  }

  reportWindow.opener = null;

  const reportTitle = `${input.vehicle.title || "Vehicle"} - Profytly AI Decision Report`;
  const generatedAt = new Date();
  const decision = getDecisionPresentation(
    input.analysis.recommendation,
    input.analysis.recommendedBid
  );

  const location = [
    input.vehicle.location,
    input.vehicle.stateCode,
  ]
    .filter(Boolean)
    .join(", ");

  const mileage =
    input.vehicle.mileage !== null
      ? `${formatNumber(input.vehicle.mileage)} ${
          input.vehicle.mileageUnit === "km" ? "km" : "miles"
        }`
      : "Not available";

  const reportHtml = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${escapeHtml(reportTitle)}</title>
  <style>
    :root {
      --ink: #111827;
      --muted: #667085;
      --line: #d9dee7;
      --soft: #f5f7fa;
      --green: #00c853;
      --green-dark: #08783d;
      --amber: #a96300;
      --red: #b42318;
      --blue: #175cd3;
    }

    * { box-sizing: border-box; }

    html, body {
      margin: 0;
      padding: 0;
      background: #eef1f5;
      color: var(--ink);
      font-family: Inter, ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }

    body { padding: 24px; }

    .report {
      max-width: 980px;
      margin: 0 auto;
      background: #fff;
      box-shadow: 0 18px 60px rgba(15, 23, 42, 0.12);
    }

    .page {
      min-height: 10in;
      padding: 34px 38px;
      background: #fff;
      break-after: page;
      page-break-after: always;
    }

    .page:last-child {
      break-after: auto;
      page-break-after: auto;
    }

    .header {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 24px;
      border-bottom: 2px solid var(--ink);
      padding-bottom: 18px;
    }

    .brand {
      font-size: 26px;
      line-height: 1;
      font-weight: 900;
      letter-spacing: -0.8px;
    }

    .brand span { color: var(--green); }

    .eyebrow {
      margin-top: 9px;
      color: var(--muted);
      font-size: 10px;
      font-weight: 800;
      letter-spacing: 1.5px;
      text-transform: uppercase;
    }

    .meta-right {
      text-align: right;
      color: var(--muted);
      font-size: 10px;
      line-height: 1.6;
    }

    h1 {
      margin: 24px 0 6px;
      font-size: 30px;
      line-height: 1.15;
      letter-spacing: -0.7px;
    }

    .vehicle-subtitle {
      color: var(--muted);
      font-size: 12px;
      line-height: 1.6;
    }

    .decision {
      margin-top: 22px;
      border: 2px solid ${decision.border};
      background: ${decision.background};
      border-radius: 14px;
      padding: 20px 22px;
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto;
      gap: 20px;
      align-items: center;
    }

    .decision-label {
      color: ${decision.color};
      font-size: 11px;
      font-weight: 900;
      letter-spacing: 1.2px;
      text-transform: uppercase;
    }

    .decision-title {
      margin-top: 7px;
      font-size: 25px;
      line-height: 1.2;
      font-weight: 900;
      color: ${decision.color};
    }

    .decision-copy {
      margin-top: 7px;
      color: #475467;
      font-size: 11px;
      line-height: 1.55;
    }

    .bid-box {
      min-width: 180px;
      border-left: 1px solid ${decision.border};
      padding-left: 22px;
      text-align: right;
    }

    .bid-box small {
      display: block;
      color: var(--muted);
      font-size: 9px;
      font-weight: 800;
      letter-spacing: 1px;
      text-transform: uppercase;
    }

    .bid-box strong {
      display: block;
      margin-top: 6px;
      color: ${decision.color};
      font-size: 29px;
      letter-spacing: -0.7px;
    }

    .metric-grid {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 10px;
      margin-top: 16px;
    }

    .metric {
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 14px;
      background: #fff;
      min-height: 92px;
    }

    .metric .label {
      color: var(--muted);
      font-size: 9px;
      font-weight: 700;
      line-height: 1.3;
    }

    .metric .value {
      margin-top: 8px;
      font-size: 20px;
      line-height: 1.15;
      font-weight: 900;
      letter-spacing: -0.4px;
    }

    .metric .value.green { color: var(--green-dark); }
    .metric .value.red { color: var(--red); }

    .metric .note {
      margin-top: 7px;
      color: var(--muted);
      font-size: 8px;
      line-height: 1.45;
    }

    .section {
      margin-top: 22px;
    }

    .section-title {
      margin: 0 0 10px;
      font-size: 14px;
      font-weight: 900;
      letter-spacing: -0.15px;
    }

    .summary {
      border: 1px solid var(--line);
      background: var(--soft);
      border-radius: 10px;
      padding: 16px 18px;
      font-size: 11px;
      line-height: 1.7;
      color: #344054;
    }

    .facts {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 8px;
    }

    .fact {
      border-bottom: 1px solid var(--line);
      padding: 8px 0 10px;
    }

    .fact .label {
      color: var(--muted);
      font-size: 8px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: .8px;
    }

    .fact .value {
      margin-top: 5px;
      font-size: 11px;
      line-height: 1.4;
      font-weight: 700;
      overflow-wrap: anywhere;
    }

    .formula {
      margin-top: 16px;
      border: 1px solid var(--line);
      border-radius: 10px;
      overflow: hidden;
    }

    .formula-row {
      display: grid;
      grid-template-columns: minmax(0, 1fr) 125px;
      gap: 16px;
      padding: 9px 14px;
      border-bottom: 1px solid var(--line);
      font-size: 10px;
    }

    .formula-row:last-child {
      border-bottom: 0;
      background: ${decision.background};
      color: ${decision.color};
      font-weight: 900;
      font-size: 12px;
    }

    .formula-row span:last-child {
      text-align: right;
      font-variant-numeric: tabular-nums;
    }

    .two-col {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 14px;
    }

    .panel {
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 15px 16px;
      break-inside: avoid;
      page-break-inside: avoid;
    }

    .panel.warning {
      border-color: #f0c36b;
      background: #fffbeb;
    }

    .panel h3 {
      margin: 0;
      font-size: 12px;
      font-weight: 900;
    }

    ul {
      margin: 10px 0 0;
      padding-left: 17px;
    }

    li {
      margin: 0 0 6px;
      color: #475467;
      font-size: 9.5px;
      line-height: 1.55;
    }

    .photos {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 8px;
    }

    .photo {
      height: 145px;
      border: 1px solid var(--line);
      border-radius: 9px;
      overflow: hidden;
      background: #eef1f5;
    }

    .photo img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    .comp-table {
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed;
      font-size: 9px;
    }

    .comp-table th,
    .comp-table td {
      border-bottom: 1px solid var(--line);
      padding: 9px 8px;
      text-align: left;
      vertical-align: top;
      overflow-wrap: anywhere;
    }

    .comp-table th {
      color: var(--muted);
      font-size: 8px;
      text-transform: uppercase;
      letter-spacing: .7px;
    }

    .comp-table td.price {
      color: var(--green-dark);
      font-weight: 900;
      text-align: right;
      white-space: nowrap;
    }

    .comp-table a {
      color: var(--blue);
      text-decoration: none;
    }

    .footer {
      margin-top: 22px;
      padding-top: 12px;
      border-top: 1px solid var(--line);
      color: var(--muted);
      font-size: 8px;
      line-height: 1.55;
    }

    .no-data {
      padding: 18px;
      border: 1px dashed var(--line);
      border-radius: 10px;
      color: var(--muted);
      font-size: 10px;
      text-align: center;
    }

    @page {
      size: Letter;
      margin: 0.35in;
    }

    @media print {
      html, body { background: #fff; }
      body { padding: 0; }
      .report { box-shadow: none; max-width: none; }
      .page { min-height: auto; padding: 0; }
      a { color: inherit; text-decoration: none; }
    }

    @media (max-width: 760px) {
      body { padding: 0; }
      .page { padding: 22px; }
      .metric-grid, .facts { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .decision { grid-template-columns: 1fr; }
      .bid-box { border-left: 0; border-top: 1px solid ${decision.border}; padding-left: 0; padding-top: 15px; text-align: left; }
      .two-col, .photos { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
  <main class="report">
    <section class="page">
      ${renderHeader(generatedAt, input.analysis.modelName)}

      <h1>${escapeHtml(input.vehicle.title || "Saved Vehicle")}</h1>
      <div class="vehicle-subtitle">
        ${escapeHtml(
          [
            input.vehicle.titleStatus,
            location || null,
            input.vehicle.lotNumber
              ? `Lot #${input.vehicle.lotNumber}`
              : null,
          ]
            .filter(Boolean)
            .join(" · ")
        )}
      </div>

      <div class="decision">
        <div>
          <div class="decision-label">AI Recommendation</div>
          <div class="decision-title">${escapeHtml(decision.label)}</div>
          <div class="decision-copy">${escapeHtml(decision.copy)}</div>
        </div>
        <div class="bid-box">
          <small>Maximum Bid</small>
          <strong>${money(input.analysis.recommendedBid)}</strong>
        </div>
      </div>

      <div class="metric-grid">
        ${renderMetric(
          "Repaired Resale Value",
          money(input.analysis.marketValueEstimate),
          rangeNote(
            input.analysis.marketValueLow,
            input.analysis.marketValueHigh
          ),
          "green"
        )}
        ${renderMetric(
          "Recommended Repair Budget",
          money(input.analysis.repairCostEstimate),
          rangeNote(
            input.analysis.repairCostLow,
            input.analysis.repairCostHigh
          ),
          "green"
        )}
        ${renderMetric(
          "Profyt Score",
          input.analysis.profytScore !== null
            ? `${input.analysis.profytScore}/100`
            : "Pending",
          "Opportunity score",
          input.analysis.recommendation === "avoid" ? "red" : ""
        )}
        ${renderMetric(
          "Confidence",
          input.analysis.confidenceScore !== null
            ? `${input.analysis.confidenceScore}%`
            : "-",
          "Strength of market evidence"
        )}
      </div>

      <div class="metric-grid">
        ${renderMetric(
          "Estimated As-Is Value",
          money(input.analysis.asIsValueEstimate),
          rangeNote(
            input.analysis.asIsValueLow,
            input.analysis.asIsValueHigh
          )
        )}
        ${renderMetric(
          "Visible Repair Cost",
          money(input.analysis.visibleRepairCostEstimate),
          rangeNote(
            input.analysis.visibleRepairCostLow,
            input.analysis.visibleRepairCostHigh
          )
        )}
        ${renderMetric(
          "Hidden Damage Contingency",
          money(input.analysis.hiddenDamageContingencyEstimate),
          rangeNote(
            input.analysis.hiddenDamageContingencyLow,
            input.analysis.hiddenDamageContingencyHigh
          )
        )}
        ${renderMetric(
          "Repair Risk",
          formatRisk(input.analysis.repairRisk),
          input.analysis.riskScore !== null
            ? `Risk score ${input.analysis.riskScore}/100`
            : "Risk score unavailable",
          input.analysis.repairRisk === "high" ? "red" : ""
        )}
      </div>

      <div class="section">
        <h2 class="section-title">Analyst Summary</h2>
        <div class="summary">${formatParagraph(
          input.analysis.summary ||
            "No written AI summary was returned."
        )}</div>
      </div>

      <div class="section">
        <h2 class="section-title">Vehicle & Auction Snapshot</h2>
        <div class="facts">
          ${renderFact("Mileage", mileage)}
          ${renderFact("Title", input.vehicle.titleStatus || "Not available")}
          ${renderFact("Source", capitalize(input.vehicle.source || "Unknown"))}
          ${renderFact("Lot", input.vehicle.lotNumber || "Not available")}
          ${renderFact("Location", location || "Not available")}
          ${renderFact("Primary Damage", input.vehicle.primaryDamage || firstItem(input.analysis.visibleDamage) || "Not available")}
          ${renderFact("Secondary Damage", input.vehicle.secondaryDamage || secondItem(input.analysis.visibleDamage) || "Not available")}
          ${renderFact("Run Condition", input.vehicle.runCondition || "Not provided")}
        </div>
      </div>

      <div class="formula">
        ${renderFormulaRow("Repaired resale value", input.analysis.marketValueEstimate)}
        ${renderFormulaRow("Target profit", -Math.abs(input.assumptions.desiredProfit))}
        ${renderFormulaRow("Recommended repair budget", -Math.abs(input.assumptions.repairs))}
        ${renderFormulaRow("Transport", -Math.abs(input.assumptions.transport))}
        ${renderFormulaRow("Auction fees", -Math.abs(input.assumptions.fees))}
        ${renderFormulaRow("AI recommended maximum bid", input.analysis.recommendedBid, true)}
      </div>

      ${renderFooter(
        input.vehicle.auctionUrl,
        generatedAt,
        "Page 1 · Decision Summary"
      )}
    </section>

    <section class="page">
      ${renderHeader(generatedAt, input.analysis.modelName)}

      <div class="section" style="margin-top: 0">
        <h2 class="section-title">Auction Photo Evidence</h2>
        ${renderPhotos(input.photoUrls)}
      </div>

      <div class="section two-col">
        ${renderListPanel("Visible Damage", input.analysis.visibleDamage, false)}
        ${renderListPanel("Hidden Damage Risks", input.analysis.hiddenDamageRisks, true)}
      </div>

      <div class="section two-col">
        ${renderListPanel("Key Factors", input.analysis.keyFactors, false)}
        ${renderListPanel("AI Warnings", input.analysis.warnings, true)}
      </div>

      <div class="section">
        <h2 class="section-title">Comparable Market Evidence</h2>
        ${renderComparableTable(input.analysis.comparableVehicles)}
      </div>

      ${
        input.notes.length > 0
          ? `<div class="section">
              <h2 class="section-title">Saved Notes</h2>
              ${renderNotes(input.notes)}
            </div>`
          : ""
      }

      ${renderFooter(
        input.vehicle.auctionUrl,
        generatedAt,
        "Page 2 · Evidence & Risk Review"
      )}
    </section>
  </main>

  <script>
    (() => {
      let printed = false;
      const printReport = () => {
        if (printed) return;
        printed = true;
        window.focus();
        window.print();
      };

      const images = Array.from(document.images);
      if (images.length === 0) {
        setTimeout(printReport, 350);
        return;
      }

      Promise.all(
        images.map((image) => {
          if (image.complete) return Promise.resolve();
          return new Promise((resolve) => {
            image.addEventListener("load", resolve, { once: true });
            image.addEventListener("error", resolve, { once: true });
          });
        })
      ).then(() => setTimeout(printReport, 450));

      setTimeout(printReport, 3500);
    })();
  </script>
</body>
</html>`;

  reportWindow.document.open();
  reportWindow.document.write(reportHtml);
  reportWindow.document.close();
}

function renderHeader(generatedAt: Date, modelName: string | null) {
  return `<div class="header">
    <div>
      <div class="brand">Profyt<span>ly</span></div>
      <div class="eyebrow">AI Vehicle Decision Report</div>
    </div>
    <div class="meta-right">
      Generated ${escapeHtml(generatedAt.toLocaleString())}<br />
      ${modelName ? `Model ${escapeHtml(modelName)}` : "AI-assisted analysis"}
    </div>
  </div>`;
}

function renderMetric(
  label: string,
  value: string,
  note: string,
  tone: "green" | "red" | "" = ""
) {
  return `<div class="metric">
    <div class="label">${escapeHtml(label)}</div>
    <div class="value ${tone}">${escapeHtml(value)}</div>
    <div class="note">${escapeHtml(note)}</div>
  </div>`;
}

function renderFact(label: string, value: string) {
  return `<div class="fact">
    <div class="label">${escapeHtml(label)}</div>
    <div class="value">${escapeHtml(value)}</div>
  </div>`;
}

function renderFormulaRow(
  label: string,
  value: number | null,
  isTotal = false
) {
  const formatted =
    value === null
      ? "-"
      : value < 0
        ? `- ${money(Math.abs(value))}`
        : money(value);

  return `<div class="formula-row${isTotal ? " total" : ""}">
    <span>${escapeHtml(label)}</span>
    <span>${escapeHtml(formatted)}</span>
  </div>`;
}

function renderListPanel(
  title: string,
  items: string[],
  warning: boolean
) {
  const cleanItems = items.filter(Boolean).slice(0, 8);

  return `<div class="panel${warning ? " warning" : ""}">
    <h3>${escapeHtml(title)}</h3>
    ${
      cleanItems.length > 0
        ? `<ul>${cleanItems
            .map((item) => `<li>${escapeHtml(item)}</li>`)
            .join("")}</ul>`
        : `<div class="no-data" style="margin-top: 10px">No items available.</div>`
    }
  </div>`;
}

function renderPhotos(photoUrls: string[]) {
  const cleanUrls = Array.from(
    new Set(
      photoUrls.filter(
        (url) =>
          typeof url === "string" &&
          /^https?:\/\//i.test(url.trim())
      )
    )
  ).slice(0, 6);

  if (cleanUrls.length === 0) {
    return `<div class="no-data">No exportable auction photo URLs were available.</div>`;
  }

  return `<div class="photos">${cleanUrls
    .map(
      (url, index) => `<div class="photo">
        <img src="${escapeAttribute(url)}" alt="Auction evidence ${
          index + 1
        }" />
      </div>`
    )
    .join("")}</div>`;
}

function renderComparableTable(
  comparables: VehicleAiReportInput["analysis"]["comparableVehicles"]
) {
  const rows = comparables
    .filter(
      (item) =>
        item.price !== null &&
        item.mileage !== null &&
        item.title.trim().length > 0
    )
    .slice(0, 6);

  if (rows.length === 0) {
    return `<div class="no-data">No verified comparable listings were available for this report.</div>`;
  }

  return `<table class="comp-table">
    <thead>
      <tr>
        <th style="width: 42%">Comparable</th>
        <th style="width: 18%">Mileage</th>
        <th style="width: 22%">Location / Source</th>
        <th style="width: 18%; text-align: right">Price</th>
      </tr>
    </thead>
    <tbody>
      ${rows
        .map(
          (item) => `<tr>
            <td>${
              item.url
                ? `<a href="${escapeAttribute(item.url)}">${escapeHtml(item.title)}</a>`
                : escapeHtml(item.title)
            }</td>
            <td>${formatNumber(item.mileage as number)}</td>
            <td>${escapeHtml(
              [item.location, capitalize(item.source)]
                .filter(Boolean)
                .join(" · ") || "-"
            )}</td>
            <td class="price">${money(item.price)}</td>
          </tr>`
        )
        .join("")}
    </tbody>
  </table>`;
}

function renderNotes(notes: VehicleAiReportInput["notes"]) {
  return `<div class="two-col">${notes
    .slice(0, 4)
    .map(
      (note) => `<div class="panel">
        <div style="font-size: 10px; line-height: 1.6; color: #344054">${formatParagraph(
          note.content
        )}</div>
        <div style="margin-top: 8px; color: #98a2b3; font-size: 8px">${escapeHtml(
          new Date(note.createdAt).toLocaleString()
        )}</div>
      </div>`
    )
    .join("")}</div>`;
}

function renderFooter(
  auctionUrl: string,
  generatedAt: Date,
  pageLabel: string
) {
  return `<div class="footer">
    <strong>${escapeHtml(pageLabel)}</strong><br />
    Generated by Profytly on ${escapeHtml(generatedAt.toLocaleString())}. This report is an AI-assisted estimate, not a mechanical inspection, title guarantee, structural measurement, or promise of resale value. Verify the vehicle, auction terms, fees, transportation, title eligibility and repair scope before bidding.
    ${
      /^https?:\/\//i.test(auctionUrl)
        ? `<br />Auction reference: <a href="${escapeAttribute(auctionUrl)}">${escapeHtml(auctionUrl)}</a>`
        : ""
    }
  </div>`;
}

function getDecisionPresentation(
  recommendation: VehicleAiReportInput["analysis"]["recommendation"],
  recommendedBid: number | null
) {
  const bid =
    recommendedBid !== null && recommendedBid > 0
      ? money(recommendedBid)
      : null;

  if (recommendation === "strong_buy") {
    return {
      label: bid ? `Strong Buy — Max ${bid}` : "Strong Buy",
      copy: "The analyzed margin and risk profile are favorable. Keep the all-in purchase price at or below the recommended maximum bid.",
      color: "#08783d",
      border: "#86d6aa",
      background: "#ecfdf3",
    };
  }

  if (recommendation === "buy") {
    return {
      label: bid ? `Buy Below ${bid}` : "Buy",
      copy: "The opportunity appears economically viable within the current evidence and cost assumptions.",
      color: "#08783d",
      border: "#86d6aa",
      background: "#ecfdf3",
    };
  }

  if (recommendation === "watch") {
    return {
      label: bid
        ? `Buy With Caution — Max ${bid}`
        : "Buy With Caution",
      copy: "The deal may work, but limited market evidence or repair uncertainty requires disciplined bidding and inspection.",
      color: "#a15c00",
      border: "#f0c36b",
      background: "#fffbeb",
    };
  }

  if (recommendation === "avoid") {
    return {
      label: "Avoid",
      copy: "No economically viable bid exists under the current resale, repair, fee, transport and profit assumptions.",
      color: "#b42318",
      border: "#f4a7a0",
      background: "#fff1f0",
    };
  }

  return {
    label: "More Data Needed",
    copy: "The available evidence is not sufficient for a defensible bid recommendation.",
    color: "#475467",
    border: "#cfd4dc",
    background: "#f8fafc",
  };
}

function rangeNote(low: number | null, high: number | null) {
  if (low === null || high === null) {
    return "Range unavailable";
  }

  return `${money(low)} – ${money(high)} range`;
}

function money(value: number | null) {
  if (value === null || !Number.isFinite(value)) {
    return "-";
  }

  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(Math.max(0, value));
}

function formatNumber(value: number) {
  return new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 0,
  }).format(value);
}

function formatRisk(value: VehicleAiReportInput["analysis"]["repairRisk"]) {
  if (!value || value === "unknown") {
    return "Unknown";
  }

  return capitalize(value);
}

function capitalize(value: string) {
  return value.length > 0
    ? `${value.charAt(0).toUpperCase()}${value.slice(1)}`
    : value;
}

function firstItem(items: string[]) {
  return items.find(Boolean) || null;
}

function secondItem(items: string[]) {
  return items.filter(Boolean)[1] || null;
}

function formatParagraph(value: string) {
  return escapeHtml(value).replace(/\n/g, "<br />");
}

function escapeHtml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function escapeAttribute(value: string) {
  return escapeHtml(value).replace(/`/g, "&#096;");
}
