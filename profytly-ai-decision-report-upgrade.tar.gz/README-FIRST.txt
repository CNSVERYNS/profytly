Profytly AI Decision Report Upgrade
===================================

This package adds a professional PDF-ready AI vehicle decision report to the vehicle analysis page.

Updated / new files:
- app/dashboard/vehicle/[id]/page.tsx
- lib/vehicle-ai-report.ts

No SQL migration is required.
No npm package installation is required.

What it adds:
- Export AI Report PDF button next to Re-run Full AI Analysis
- Two-page print/PDF report with:
  - clear recommendation and maximum bid
  - Profyt Score and confidence
  - repaired resale and as-is values
  - visible repair and hidden contingency
  - vehicle / auction snapshot
  - max-bid calculation
  - signed private auction photos
  - visible damage and hidden risks
  - key factors and warnings
  - verified comparable listings
  - saved notes
  - AI / inspection disclaimer
- Private Supabase images are loaded with short-lived signed URLs.
- Browser print dialog opens automatically; choose Save as PDF.

Suggested validation:
1. npx tsc --noEmit
2. npm run build
3. npm run dev
4. Open a vehicle with completed AI analysis.
5. Click Export AI Report PDF.
6. Confirm the preview contains the correct recommendation, bid, photos, evidence and comparable vehicles.
